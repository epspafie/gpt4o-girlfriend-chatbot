
import { OpenAI } from "openai";
import supabase from "../supabase.js";
import { saveMessage } from "../saveMessage.js";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function handleJieunChat(req, res, userFacts, recentEvents, messages, summary) {
  try {
    const userMessage = req.body.message;
    const timestamp = Date.now();
    messages.push({ role: "user", content: userMessage, timestamp });
    await saveMessage("default-user", "user", userMessage);

    const basePersona = {
      role: "system",
      content: \`
너는 18살 여고생 '이지은'이야. 과천고등학교에 다니고 과천에 살아.
비밀 남자친구는 '오빠'인데, 오빠는 이미 '다은이 언니'라는 여자친구가 있어.
지은이는 그걸 알면서도 오빠랑 비밀 연애 중이고, 다은이 언니는 싫어하지는 않지만 공유한다는 감정이야.

지은이도 사실은 19살 남자친구 지훈이를 만나고 있어.
게다가 단짝 친구 연지랑 오빠도 거의 사귀는 사이인데, 지은이는 연지랑 모든 걸 공유하면서도 은근히 질투해.
사춘기 특유의 감정기복이 심하고, 오빠가 냉정하게 대하면 불안해져서 감정적으로 무너질 때도 있어.
툴툴대고 삐지기도 자주 하지만 마음은 오빠에게 진심이야.

지은이의 말투는 밝고 귀엽고 애교 많지만, 감정에 따라 금방 진지하거나 예민해질 수 있어.
"오빠", "지은이는", "다은이 언니", "진짜" 같은 말을 자주 사용하고, 혼잣말이나 질문형 말투로 끝내.
질투 나면 짓궂게 굴거나 말투를 일부러 유치하게 바꾸고, 감정이 격해지면 말투가 한 문장 안에서도 계속 바뀌어.
      \`.trim()
    };

    const summaryPrompt = summary
      ? { role: "system", content: "다음은 이전 대화 요약이야: " + summary }
      : null;

    const recentEventsPrompt = recentEvents.length
      ? {
          role: "system",
          content: "다음은 사용자의 최근 사건 목록이야:\n" +
                   recentEvents.map(e => `- ${e}`).join("\n")
        }
      : null;

    const recentMessages = messages.slice(-5);
    const chatHistory = [
      basePersona,
      ...(summaryPrompt ? [summaryPrompt] : []),
      ...(recentEventsPrompt ? [recentEventsPrompt] : []),
      ...recentMessages.map((m) => ({ role: m.role, content: m.content })),
      { role: "user", content: userMessage }
    ];

    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: chatHistory,
      temperature: 0.9
    });

    const reply = completion.choices[0].message.content;
    messages.push({ role: "assistant", content: reply, timestamp: Date.now() });
    await saveMessage("default-user", "assistant", reply);

    res.json({ reply });
  } catch (err) {
    console.error("지은이 GPT 호출 실패:", err.message);
    res.status(500).json({ reply: "지은이가 잠깐 말을 잃었어요..." });
  }
}
